//
//  SecondViewController.swift
//  CoreDataDemo
//
//  Created by webwerks on 2/17/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var firstName : UITextField!
    @IBOutlet weak var middleName : UITextField!
    @IBOutlet weak var lastName : UITextField!
    @IBOutlet weak var address : UITextField!
    @IBOutlet weak var mobileNumber : UITextField!
   
    var firstNameStr : String?
    var middleNameStr : String?
    var lastNameStr : String?
    var addressStr : String?
    var mobileNumberStr : String?
    var index : Int?
    
    var isEdit = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        firstName.text = firstNameStr
        middleName.text = middleNameStr
        lastName.text = lastNameStr
        address.text = addressStr
        mobileNumber.text = mobileNumberStr
    }
    @IBAction func onClickSave(_ sender : UIButton) {
        
        if isEdit {
            print("UPdate")
            let dict = ["name": firstName.text , "middleName": middleName.text,"lastName": lastName.text, "address":address.text ,"mobNumber":mobileNumber.text]
                            
            DatabaseHelper.share.editData(index: index ?? 0, dict: dict as! [String : String])
        } else {
            let dict = ["name": firstName.text , "middleName": middleName.text,"lastName": lastName.text, "address":address.text ,"mobNumber":mobileNumber.text]
                   DatabaseHelper.share.save(object: dict as! [String : String])
        }
    } 
}

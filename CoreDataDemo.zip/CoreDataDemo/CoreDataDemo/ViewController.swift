//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by webwerks on 2/17/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
 @IBOutlet weak var tableView : UITableView!
    var student = [Student]() 
    override func viewDidLoad() {
        super.viewDidLoad()
       tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        student = DatabaseHelper.share.getStudentData()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        student = DatabaseHelper.share.getStudentData()
         tableView.reloadData()
    }
    
    
    @IBAction func onclickAdd(_ sender : UIBarButtonItem) {
       
        let vc = self.storyboard?.instantiateViewController(identifier: "SecondViewController") as! SecondViewController
       
        navigationController?.pushViewController(vc, animated: true)
    }
}
extension ViewController : UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return student.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.nameLbl.text = student[indexPath.row].name
        cell.middleNameLbl.text = student[indexPath.row].middleName
        cell.lastNameLbl.text = student[indexPath.row].lastName
        cell.mobileNumberLbl.text = student[indexPath.row].mobNumber
        cell.addressLbl.text = student[indexPath.row].address
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            student = DatabaseHelper.share.deleteData(index: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(identifier: "SecondViewController") as! SecondViewController
        vc.firstNameStr =  student[indexPath.row].name
        vc.middleNameStr = student[indexPath.row].middleName
        vc.lastNameStr = student[indexPath.row].lastName
        vc.mobileNumberStr = student[indexPath.row].mobNumber
        vc.addressStr = student[indexPath.row].address
        vc.isEdit = true
        vc.index = indexPath.row
        navigationController?.pushViewController(vc, animated: true)
    }
}





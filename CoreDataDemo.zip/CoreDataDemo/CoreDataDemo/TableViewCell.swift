//
//  TableViewCell.swift
//  CoreDataDemo
//
//  Created by webwerks on 2/17/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var nameLbl : UILabel!
    @IBOutlet weak var middleNameLbl : UILabel!
     @IBOutlet weak var lastNameLbl : UILabel!
     @IBOutlet weak var addressLbl : UILabel!
     @IBOutlet weak var mobileNumberLbl : UILabel!
    
    
      
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

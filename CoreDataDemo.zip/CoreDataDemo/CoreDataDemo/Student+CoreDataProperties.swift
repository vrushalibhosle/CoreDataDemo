//
//  Student+CoreDataProperties.swift
//  CoreDataDemo
//
//  Created by webwerks on 2/17/20.
//  Copyright © 2020 webwerks. All rights reserved.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var name: String?
    @NSManaged public var middleName: String?
    @NSManaged public var lastName: String?
    @NSManaged public var mobNumber: String?
    @NSManaged public var address: String?

}

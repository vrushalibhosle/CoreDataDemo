//
//  DatabaseHelper.swift
//  CoreDataDemo
//
//  Created by webwerks on 2/17/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DatabaseHelper {
    
    static let share = DatabaseHelper()
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func save(object : [String:String]) {
        let student = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context!) as! Student
        
        student.name = object["name"]
        student.middleName = object["middleName"]
        student.lastName = object["lastName"]
        student.address = object["address"]
        student.mobNumber = object["mobNumber"]
        
        do{
            try context?.save()
        }catch{
            print("Data is not save")
        }
    }
    
    func getStudentData() -> [Student] {
        var student = [Student]()
        
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "Student") 
        do{
            student = try context?.fetch(fetchReq) as! [Student]
            
        } catch {
            print("could not get data")
        }
        return student
    }
    
    func deleteData(index : Int) -> [Student] {
        var student = getStudentData()
        context?.delete(student[index])
        student.remove(at: index)
        do{
            try context?.save()
        }catch{
            print("can not delete data")
        }
        return student
    }
    
    
    func editData(index : Int, dict : [String: String]) {
        let student = getStudentData()
        student[index].name = dict["name"]
        student[index].middleName = dict["middleName"]
        student[index].lastName = dict["lastName"]
        student[index].mobNumber = dict["mobNumber"]
        student[index].address = dict["address"]
        
        do {
            try context?.save()
        }catch{
            print("not save")
        }
    }
}
